As funcionalidades implementadas são:

GET: Obter a lista de professores ou um professor específico.
POST: Adicionar um novo professor.
PUT: Atualizar um professor existente.
DELETE: Remover um professor.

1.Pré-requisitos:
	Java JDK
	Eclipse IDE
	Docker
	Postman

2.Configurar o Banco de Dados com Docker
	
	Executar comandos:

docker pull postgres:latest

docker run --name professores-postgres -e POSTGRES_PASSWORD=sua_senha -e POSTGRES_USER=seu_usuario -e POSTGRES_DB=professoresdb -p 5432:5432 -d postgres

docker ps


3.Executar o Projeto no Eclipse

File > Import....
Selecionar Existing Maven Projects em Maven.
Navegar até o diretório raiz do projeto.
Na classe principal da aplicação "ProfessoresApiApplication.java", com o botão direito selecionar run as > java application.

4.Testar API no Postman 

url: http://localhost:8080/professores

POST -> Ir a body,selecionar raw e em JSON, inserir por exemplo:

{
    "nome": "Pedro",
    "departamento": Eletrónica"
}


GET -> é so fazer get para listar todos
caso seja alguém em especifico por id -> url: http://localhost:8080/professores/id

lista por nome de professor: url: http://localhost:8080/professores/search?nome=pedro



PUT -> url: http://localhost:8080/professores/id
e simplesmente atualizar o campo:
{
    "nome": "Pedro",
    "departamento": Ambiente"
}

DELETE de um id especifico ->
http://localhost:8080/professores/id


5. Erros

Caso não seja inserido nome ou departamento, a aplicação retorna uma mensagem.

