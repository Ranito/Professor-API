package com.exemplo.professoresapi.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import com.exemplo.professoresapi.model.Professor;
import java.util.List;

public interface ProfessorRepository extends JpaRepository<Professor, Long> {
    
	List<Professor> findByNomeContainingIgnoreCase(String nome);
	
}