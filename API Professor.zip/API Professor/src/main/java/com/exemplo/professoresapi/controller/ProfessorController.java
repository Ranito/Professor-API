package com.exemplo.professoresapi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.exemplo.professoresapi.model.Professor;
import com.exemplo.professoresapi.repository.ProfessorRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import javax.validation.Valid;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.http.HttpStatus;

@RestController
@RequestMapping("/professores")
public class ProfessorController {
	
	
    @Autowired
    private ProfessorRepository professorRepository;

    // Endpoint GET
    @GetMapping
    public List<Professor> listarProfessores() {
        return professorRepository.findAll();
    }

     //Endpoint GET for nome professor
    @GetMapping("/search")
    public List<Professor> buscarProfessoresPorNome(@RequestParam String nome) {
        return professorRepository.findByNomeContainingIgnoreCase(nome);
    }
    
    // Endpoint POST
    @PostMapping
    public ResponseEntity<Professor> adicionarProfessor(@Valid @RequestBody Professor professor) {
        Professor savedProfessor = professorRepository.save(professor);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedProfessor);
    }
    
    //Endpoint Delete
    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deletarProfessor(@PathVariable Long id) {
        return professorRepository.findById(id)
            .map(professor -> {
                professorRepository.delete(professor);
                return ResponseEntity.noContent().build();
            })
            .orElse(ResponseEntity.notFound().build());
    }
    
    //Endpoint Update
    @PutMapping("/{id}")
    public ResponseEntity<Professor> atualizarProfessor(@PathVariable Long id, @RequestBody Professor detalhesProfessor) {
        return professorRepository.findById(id)
            .map(professor -> {
                professor.setNome(detalhesProfessor.getNome());
                professor.setDepartamento(detalhesProfessor.getDepartamento());
                Professor professorAtualizado = professorRepository.save(professor);
                return ResponseEntity.ok(professorAtualizado);
            })
            .orElse(ResponseEntity.notFound().build());
    }
    //Endpoint get for id professor
    @GetMapping("/{id}")
    public ResponseEntity<Professor> obterProfessor(@PathVariable Long id) {
        return professorRepository.findById(id)
            .map(professor -> ResponseEntity.ok(professor))
            .orElse(ResponseEntity.notFound().build());
    }

}

