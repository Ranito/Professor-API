package com.exemplo.professoresapi.model;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
public class Professor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
   
    @NotBlank(message = "O nome é obrigatório")
    @Size(max = 100, message = "O nome deve ter no máximo 100 caracteres")
    
    private String nome;
    
    @NotBlank(message = "O departamento é obrigatório")
    @Size(max = 100, message = "O nome deve ter no máximo 100 caracteres")
    private String departamento;

    // Construtores
    public Professor() {
    }

    public Professor(String nome, String departamento) {
        this.nome = nome;
        this.departamento = departamento;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }
}
