package com.exemplo.professoresapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProfessoresApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProfessoresApiApplication.class, args);
    }
}
